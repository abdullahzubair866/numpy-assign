# AI-Q2-learning-resources
AIC Quarter 2 Learning and practice resources
